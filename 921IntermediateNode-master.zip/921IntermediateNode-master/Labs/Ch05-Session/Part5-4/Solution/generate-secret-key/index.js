'use strict';

const crypto = require("crypto");

console.log(crypto.randomBytes(48).toString("base64"));

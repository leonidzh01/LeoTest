function average(a,b,c) {
    sum = a + b + c

    avg = sum / 3

    return a/c
}
function add(a,b) {
    return a + c
}
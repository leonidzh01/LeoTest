## quick saves:
Ctrl + S

## Undo
Ctrl + Z

## copy
Ctrl + C

## paste
Ctrl + V

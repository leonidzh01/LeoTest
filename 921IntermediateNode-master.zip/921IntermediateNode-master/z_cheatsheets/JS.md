## JavaScript

* let and const have block scope
* var can cause memory leaks due to not being block scoped

## Browse these other cheatsheets

* http://htmlcheatsheet.com/js/
* https://github.com/mbeaudru/modern-js-cheatsheet


Open a terminal window here (right click, open in terminal in VSCode) 

go through the 1fileio-examples in numerical order. 

    Read the content of each file in this directory before executing it. 
    Pay attention to the order of console.log statements.

notice that the 2dirs directory has a package.json. Use `npm install` to do the install of dependencies

    What is the dependency? How can you find out about its usage?
    
    Read the content of each file in this directory before executing it. 
    Pay attention to the order of console.log statements.


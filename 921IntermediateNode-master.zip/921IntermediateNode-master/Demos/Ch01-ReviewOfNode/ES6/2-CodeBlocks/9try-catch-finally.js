
            try {
               // Block of code to try
            }
            catch(err) {
               // Block of code to handle errors
            } 
            finally {
               // Block of code to be executed regardless 
               // of the try / catch result
            }

            try {
               console.log(undefinedVar);
            }
            catch(err) {
               console.log(err);
            } 


            
            finally {
               // Block of code to be executed regardless 
               // of the try / catch result
            }




           //check for Range Error
           // call check()

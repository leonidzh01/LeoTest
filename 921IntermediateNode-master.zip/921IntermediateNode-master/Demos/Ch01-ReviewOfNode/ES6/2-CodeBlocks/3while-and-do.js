
           let counter = 0;
           while (counter <= 5) {
                console.log("Counter: " + counter++);
           }

           const pets = [
                {name: 'Birdy', type: 'cat'},
                {name: 'Roxy', type: 'dog'}
           ]
        
           for (let index = 0; index < pets.length; index++) {
               console.log(index);
               console.log(pets[index].name + " is a " + pets[index].type);
           }

            //for


            // while

            // do while

            //for..of iterator
      

const simpleNameArray = ['Adam',
    'Judy',
    'Cody'];

console.log(simpleNameArray[0]);

const ages = [45, 41, 1];

const person = {
    name: "Adam",
    age: 45
}

const oneArray = [1, 2, 3];
const secondArray = [1, 2, 3];

console.log(oneArray == secondArray)



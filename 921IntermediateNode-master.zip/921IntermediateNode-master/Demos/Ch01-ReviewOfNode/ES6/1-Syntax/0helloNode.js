//open the directory from a command window or terminal
//type node hello.js
console.log('Hello from Node.');
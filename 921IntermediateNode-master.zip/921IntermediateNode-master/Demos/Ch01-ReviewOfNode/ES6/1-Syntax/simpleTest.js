console.log('Hello Universe');
var x;

if (x === 'undefined') {
    console.log('x is equivalent of string undefined');
}

if (x === undefined) {
    console.log('x is equivalent of keyword undefined');
}

var y;

if (typeof y === 'undefined') {
    console.log('y is undefined')
}


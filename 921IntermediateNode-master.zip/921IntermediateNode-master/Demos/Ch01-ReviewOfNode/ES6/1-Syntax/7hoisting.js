
            y;
            var y = 5;

         //   z;              // ReferenceError: x is not defined
         //   const z = 3;
            
            x;              // ReferenceError: x is not defined
            let x = 3;  
        
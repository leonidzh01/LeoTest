# Demo Chapter 06 - Transpiling Demo with Demo

1. View index.html - what script is being included?

1. View the package.json - what are the dependencies?

1. Use npm install to get the dependencies

1. Notice how the build script uses the babel cli to create a dist directory from the src directory files. 
Execute the build script using npm run build.  It will keep running, transpiling changes because of the watch flag.

1. Load the index.html in Chrome.
